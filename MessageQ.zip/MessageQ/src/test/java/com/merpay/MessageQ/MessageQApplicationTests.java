package com.merpay.MessageQ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageQApplicationTests {

	@Test
	void contextLoads() {
	}

}
