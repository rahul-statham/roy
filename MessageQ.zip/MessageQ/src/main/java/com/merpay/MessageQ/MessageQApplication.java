package com.merpay.MessageQ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessageQApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessageQApplication.class, args);
	}

}
